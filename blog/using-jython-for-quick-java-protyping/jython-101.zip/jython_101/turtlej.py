"""
Compilation: None 
Execution:  java -classpath ./lib/* org.python.util.jython ./turtlej.py
Dependencies: jython-standalone-2.7.2.jar, stdlib.jar

A demonstration of some key features of Jython Java library.
It 
"""

# java class import(class belongs to a namespace)
from java.awt import Color
from java.lang import Math

import StdDraw

# cmd:  java -classpath ./lib/* org.python.util.jython turtlej.py

class Turtle(object):

    def __init__(self, x0, y0, a0):
        self.x = x0
        self.y = y0
        self.angle = a0

    # rotate orientation delta degrees counterclockwise
    def turnLeft(self, delta):
        self.angle += delta

    # rotate orientation delta degrees clockwise
    def turnRight(self, delta):
        self.angle -= delta

    # move forward the given amount, with the pen down
    def goForward(self, step):
        oldx = self.x
        oldy = self.y
        self.x += step * Math.cos(Math.toRadians(self.angle))
        self.y += step * Math.sin(Math.toRadians(self.angle))
        StdDraw.line(oldx, oldy, self.x, self.y)

    # copy to onscreen
    @staticmethod
    def show():
        StdDraw.show()

    # pause t milliseconds
    @staticmethod
    def pause(t):
        StdDraw.pause(t)

    @staticmethod
    def setPenColor(color):
        StdDraw.setPenColor(color)

    @staticmethod
    def setPenRadius(radius):
        StdDraw.setPenRadius(radius)

    @staticmethod
    def setCanvasSize(width, height):
        StdDraw.setCanvasSize(width, height)

    @staticmethod
    def setXscale(min, max):
        StdDraw.setXscale(min, max)

    @staticmethod
    def setYscale(min, max):
        StdDraw.setYscale(min, max)


class Algorithms(object):

    @staticmethod
    def hilbert(turtle, size, order, parity):
        """draws a Hilbert SFC orders > 7 take quite long to draw"""
        # recursive base case
        if order == 0:
            return	

        # rotate and draw first subcurve with opposite parity to big curve
        turtle.turnLeft(parity * 90)
        Algorithms.hilbert(turtle, size, order - 1, -parity)
        # interface to and draw second subcurve with same parity as big curve
        turtle.goForward(size)
        turtle.turnRight(parity * 90)
        turtle.show()
        Algorithms.hilbert(turtle, size, order - 1, parity)

        # third subcurve
        turtle.goForward(size)
        Algorithms.hilbert(turtle, size, order - 1, parity)

        # fourth subcurve
        turtle.turnRight(parity * 90)
        turtle.goForward(size)
        Algorithms.hilbert(turtle, size, order - 1, -parity)
        # a final turn is needed to make the turtle
        # end up facing outward from the large square
        turtle.turnLeft(parity * 90)

    @staticmethod
    def polygon(turtle, step, n=5, min_size=25, size_decrease=2):
        """draws smaller and smaller polygons with each recursive iteration"""

        # base case for smallest possible polygon
        if step < min_size or step < 1:
            return

        for _ in range(0, n):
            turtle.goForward(step)
            Algorithms.polygon(turtle, step/size_decrease, n)
            turtle.turnLeft(360/n)  # 360/n is the exterior angle of a regular polygon
            turtle.pause(50)
            turtle.show()

    @staticmethod
    def main():
        x_size, y_size = 800, 800
        Turtle.setCanvasSize(x_size, y_size)
        # by default x,y scale  is in range (0,1) lets make it in pixels, not unit square
        Turtle.setXscale(0, x_size)
        Turtle.setYscale(0, y_size)

        # creates the illusion of animated drawing
        StdDraw.enableDoubleBuffering()

        phc_order = 5
        order_size = x_size/((2**phc_order) + 2) # the width is proportional to the square of the order
        my_turtle = Turtle(order_size, order_size, 0)

        # draw pseudo hilbert curve
        Algorithms.hilbert(my_turtle, order_size, phc_order, 1)
        Turtle.show()

        # draw polygon
        StdDraw.clear()
        # reset turtle coordinates to the center
        my_turtle.x = x_size / 2
        my_turtle.y = y_size / 2

        Algorithms.polygon(my_turtle, step=200, n=4, min_size=10, size_decrease=2)
        Turtle.show()



if __name__ == "__main__":
    Algorithms.main()



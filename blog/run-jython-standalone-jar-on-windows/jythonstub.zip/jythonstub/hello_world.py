"""
Basic Jython script to verify that environment setup was successful.

execution: java -classpath ./lib/* org.python.util.jython ./hello_world.py
"""

from java.lang import System

print("PYTHON: Hello World!")
System.out.println("JAVA: Hello World!")

import graphene
from fastapi import FastAPI
from starlette_graphene3 import GraphQLApp

from data_structures import ObjectMgr, ListPool

object_manager = ObjectMgr(ListPool())


class FreeObject(graphene.Mutation):
    obj = graphene.Int()

    class Arguments:
        obj = graphene.Int(required=True)

    def mutate(self, info, obj):
        object_manager.free_object(obj)
        return FreeObject(
            obj=obj,
        )


class Mutation(graphene.ObjectType):
    free_object = FreeObject.Field()


class Query(graphene.ObjectType):
    objectMgr = graphene.Int()

    @staticmethod
    def resolve_objectMgr(root, info):
        return object_manager.get_object()


app = FastAPI()
schema = graphene.Schema(query=Query, mutation=Mutation)
app.mount("/graphql", GraphQLApp(schema=schema))

import unittest
from data_structures import ObjectMgr, ListPool


class TestMain(unittest.TestCase):
    def setUp(self) -> None:
        self.target = ObjectMgr(ListPool())
        return super().setUp()

    def test_get_object_returns_none_when_pool_is_empty(self):
        self.assertIsNone(self.target.get_object())

    def test_object_is_added_to_the_pool(self):
        expected = 33
        self.target.free_object(expected)
        self.assertIs(self.target.get_object(), expected)

    def test_same_object_is_not_inserted_in_the_pool_twice(self):
        obj = (1,)  # Tuple of ints implements a hashable interface
        self.target.free_object(obj)
        self.target.free_object(obj)

        self.assertListEqual(self.target.pool, [obj])

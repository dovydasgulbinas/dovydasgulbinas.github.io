from collections.abc import Hashable
import logging
from typing import Any, Protocol

logging.basicConfig(level=logging.DEBUG)


class Pool(Protocol):
    def pop_object(self) -> Hashable:
        ...

    def append_object(self, obj: Hashable) -> None:
        ...

    def is_in_pool(self, obj: Hashable) -> bool:
        ...

    def is_empty(self) -> bool:
        ...


class ListPool(list, Pool):
    def pop_object(self) -> Hashable:
        # I could of chose random index popping, but I wanted the code to be clean
        return self.pop(0)

    def append_object(self, obj: Hashable) -> None:
        self.append(obj)

    def is_in_pool(self, obj: Hashable) -> bool:
        return obj in self

    def is_empty(self) -> bool:
        return len(self) == 0


class ObjectMgr:
    def __init__(self, pool_class: Pool):
        self.pool: Pool = pool_class

    def get_object(self) -> Any | None:
        """Returns any object available in the pool.
        An object cannot be given away unless it has been freed.
        """

        if self.pool.is_empty():
            # There are no available objects in the pool.
            logging.info("The pool is empty, no objects to return.")
            return None

        return self.pool.pop_object()

    # I know that the assignment required obj to be of type <int>
    # I wanted to ObjectMgr more "future proof""
    def free_object(self, obj: Hashable) -> None:
        """Pushes the object back to the pool so that it can received again."""
        # The Python's built-in `in` operator this will not work
        if self.pool.is_in_pool(obj):
            logging.error(
                f"The {obj=} is already in the object pool, it won't be added."
            )
            return

        self.pool.append_object(obj)

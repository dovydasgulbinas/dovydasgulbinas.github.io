# Tromzo Assignment

I have included the coding challenge we discussed below.
Please submit your solution within 7 days from today.
If you need more time or if you have any questions, don't hesitate to let me know.

## STEP 1:
Design an `ObjectMgr` which manages a pool of objects. Objects can be considered to be `ints` (from 1 to n). It should provide API’s to get_object() and free_object():

`get_object():` Returns any object available in the pool. An object cannot be given away again unless it has been freed.
`free_object(int obj):` Returns the object back to the pool so that it can be given out again.

Please document the API’s definitions, data structures and write tests.

## STEP 2:
1. Write a GraphQL API schema to use the above functions to create, get and free objects.
2. Deploy it as a service/container that can be used to deploy on a Linux server.

We prefer that you use Python but feel free to use standard libraries in your solution.

We look forward to seeing your solution!

## Design Decisions & Limitations

* The object pool is lost when container/program exists.
* By design this code is not suitable for vertically scaled environments such as K8s
    * Although a share state or object queue could be easily implemented by using depedency injection for Pool interface.
* The reason why I chose not to have a shared object pool was simplicity of deployment and code

## Running The Project

1. Run the built docker image:

    docker run -p 8080:80 -it megamorphf/assignment-tromzo:latest

2. Try out the GQL queries

Add an object to the object pool:
```gql
mutation{
  freeObject(
    obj: 33,
  ){
  obj
  }
}
```
curl request:

```bash
curl --request POST \
  --url http://127.0.0.1:8080/graphql \
  --header 'Accept: application/json' \
  --header 'Accept-Encoding: gzip, deflate, br' \
  --header 'Connection: keep-alive' \
  --header 'Content-Type: application/json' \
  --header 'DNT: 1' \
  --header 'Origin: http://127.0.0.1:8080' \
  --data '{"query":"mutation {\n  freeObject(obj: 33) {\n    obj\n  }\n}\n"}'
```

Get any object from the object pool:
```gql
{
	objectMgr
}
```

curl request:
```bash
curl --request POST \
  --url http://localhost:8080/graphql \
  --header 'Accept: application/json' \
  --header 'Accept-Encoding: gzip, deflate, br' \
  --header 'Connection: keep-alive' \
  --header 'Content-Type: application/json' \
  --header 'DNT: 1' \
  --header 'Origin: http://localhost:8080' \
  --data '{"query":"{\n\tobjectMgr\n}"}'
```

## Extra Commands For Development:

install development dependencies:

    make init

run unit tests:

    make

run the development server:

    make run

build a production image:
    
    make img-build


publish a production image:
    
    make img-publish

    
start the built container:

    make img-run

